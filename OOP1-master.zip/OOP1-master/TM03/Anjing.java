public class Anjing extends Hewan{
    boolean statusSuntikRabies ;
    
    @Override
    boolean status(){
        return statusSuntikRabies;
    }
}