public class Ikan extends Hewan{
    boolean statusGantiAir ;
    
    public boolean status(){
        return statusGantiAir;
    }
}