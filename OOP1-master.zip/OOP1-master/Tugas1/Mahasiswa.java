public class Mahasiswa {
    //atribut nim, nama, kelas
    String nim, nama, kelas;

}